# Documentation

This folder contains stable product documentation.

## Index

- [architecture.md](architecture.md) summarizes the intended system shape.
- [governance.md](governance.md) records hard project rules.
- [architecture/server.md](architecture/server.md) records backend architecture
  guidance.
- [architecture/web.md](architecture/web.md) records frontend architecture
  guidance.
- [architecture/orchestration.md](architecture/orchestration.md) records local
  orchestration guidance.
- [modules/README.md](modules/README.md) indexes module documentation.
- [platform/README.md](platform/README.md) indexes platform concerns.
- [testing.md](testing.md) summarizes the testing strategy.
- [openspec.md](openspec.md) describes how this repository uses OpenSpec.
